final Map<String, String> enUs = {
  // splash screen Screen
  "lbl_10_40": "10:40",
  "lbl_get_started": "GET STARTED",
  "msg_effortlessly_expand":
      "\"Effortlessly Expand Your Product Range:\n Add Variants with Ease\"",
  "msg_sip_savour_juice": "SIP & SAVOUR JUICE",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
