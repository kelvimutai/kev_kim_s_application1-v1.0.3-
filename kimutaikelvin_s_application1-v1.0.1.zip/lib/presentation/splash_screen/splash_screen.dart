import 'package:kimutaikelvin_s_application1/widgets/custom_elevated_button.dart';
import 'models/splash_model.dart';
import 'package:flutter/material.dart';
import 'package:kimutaikelvin_s_application1/core/app_export.dart';
import 'bloc/splash_bloc.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<SplashBloc>(
      create: (context) => SplashBloc(SplashState(
        splashModelObj: SplashModel(),
      ))
        ..add(SplashInitialEvent()),
      child: SplashScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashBloc, SplashState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: double.maxFinite,
              child: Column(
                children: [
                  _buildOne(context),
                  SizedBox(height: 75.v),
                  Text(
                    "msg_sip_savour_juice".tr,
                    style: theme.textTheme.headlineLarge,
                  ),
                  SizedBox(height: 18.v),
                  CustomImageView(
                    imagePath: ImageConstant.imgUndrawUndrawS,
                    height: 281.v,
                  ),
                  Spacer(
                    flex: 55,
                  ),
                  Container(
                    width: 394.h,
                    margin: EdgeInsets.only(
                      left: 15.h,
                      right: 19.h,
                    ),
                    child: Text(
                      "msg_effortlessly_expand".tr,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                  SizedBox(height: 84.v),
                  CustomElevatedButton(
                    text: "lbl_get_started".tr,
                    margin: EdgeInsets.only(
                      left: 27.h,
                      right: 26.h,
                    ),
                  ),
                  Spacer(
                    flex: 44,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildOne(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(right: 28.h),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgEllipse1,
              height: 58.v,
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 8.h,
                top: 21.v,
                bottom: 9.v,
              ),
              child: Text(
                "lbl_10_40".tr,
                style: CustomTextStyles.titleMediumPoppins,
              ),
            ),
            Spacer(),
            CustomImageView(
              imagePath: ImageConstant.imgWifi,
              height: 25.adaptSize,
              width: 25.adaptSize,
              margin: EdgeInsets.only(
                top: 24.v,
                bottom: 9.v,
              ),
            ),
            CustomImageView(
              imagePath: ImageConstant.imgSettings,
              height: 20.v,
              margin: EdgeInsets.only(
                left: 10.h,
                top: 24.v,
                bottom: 12.v,
              ),
            ),
            CustomImageView(
              imagePath: ImageConstant.imgBatteryThreeQuarters,
              height: 25.adaptSize,
              width: 25.adaptSize,
              margin: EdgeInsets.only(
                left: 9.h,
                top: 24.v,
                bottom: 9.v,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
