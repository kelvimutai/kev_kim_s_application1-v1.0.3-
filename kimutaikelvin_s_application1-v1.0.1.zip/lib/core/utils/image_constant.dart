class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // splash screen images
  static String imgEllipse1 = '$imagePath/img_ellipse_1.png';

  static String imgWifi = '$imagePath/img_wifi.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgBatteryThreeQuarters =
      '$imagePath/img_battery_three_quarters.svg';

  static String imgUndrawUndrawS = '$imagePath/img_undraw_undraw_s.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
